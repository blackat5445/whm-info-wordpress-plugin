(function($) {
    'use strict';
    $(document).ready(function() {
        $('#whmic-settings-form').on('submit', function(e) {
            e.preventDefault();
            const $form = $(this);
            const $button = $('#whmic-test-connection');
            const $spinner = $form.find('.spinner');
            const $message = $('#whmic-response-message');

            $button.prop('disabled', true);
            $spinner.addClass('is-active');
            $message.hide().removeClass('success error');

            $.post(WHMIC_Ajax.ajax_url, {
                action: 'whmic_test_connection',
                nonce: WHMIC_Ajax.nonce,
                api_url: $('#whmic-api-url').val(),
                api_key: $('#whmic-api-key').val()
            }).done(function(response) {
                if (response.success) {
                    $message.addClass('success').text(response.data.message).show();
                    setTimeout(() => location.reload(), 1000); // Reload to show new status
                } else {
                    $message.addClass('error').text(response.data.message).show();
                }
            }).fail(function() {
                $message.addClass('error').text('An unknown error occurred.').show();
            }).always(function() {
                $button.prop('disabled', false);
                $spinner.removeClass('is-active');
            });
        });
    });
})(jQuery);