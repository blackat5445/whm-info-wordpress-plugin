<div class="whmic-card whmic-consent-card">
    <h1><?php _e('Consent to Connect', 'whmin-connect'); ?></h1>
    <p><?php _e('To use the WHM Info Connect plugin, you must consent to sharing basic information about your WordPress installation with the source API URL you provide. This data helps monitor your site\'s health and includes:', 'whmin-connect'); ?></p>
    <ul>
        <li><?php _e('General site information (WordPress Version, PHP Version).', 'whmin-connect'); ?></li>
        <li><?php _e('Basic server information as provided by WordPress.', 'whmin-connect'); ?></li>
        <li><?php _e('Information about disk space usage.', 'whmin-connect'); ?></li>
    </ul>
    <p><?php _e('Your API key will be stored in your database to authorize this connection. By clicking "Accept", you agree to these terms.', 'whmin-connect'); ?></p>

    <form method="post" class="whmic-consent-actions">
        <?php wp_nonce_field('whmic_consent_nonce'); ?>
        <button type="submit" name="whmic_consent_action" value="accept" class="button button-primary button-hero">
            <?php _e('Accept & Continue', 'whmin-connect'); ?>
        </button>
        <button type="submit" name="whmic_consent_action" value="decline" class="button button-secondary button-hero">
            <?php _e('Decline', 'whmin-connect'); ?>
        </button>
    </form>
</div>