<?php
/**
 * Plugin Name:       WHM Info Connect
 * Plugin URI:        https://www.agenziamagma.it
 * Description:       Key plugin to connect to WHM Info plugin and show the status of the services.
 * Version:           1.0.0
 * Author:            Kasra Falahati, Agenzia Magma
 * Author URI:        https://www.kasra.eu
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       whmin-connect
 * Domain Path:       /languages
 */

if (!defined('ABSPATH')) exit;

define('WHMIC_PATH', plugin_dir_path(__FILE__));
define('WHMIC_VERSION', '1.0.0');

class WHM_Info_Connect {

    const REST_NAMESPACE       = 'whmin-connect/v1';
    const META_TRANSIENT_KEY   = 'whmic_site_meta_cache';

    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_whmic_test_connection', [$this, 'ajax_test_connection']);

        // NEW: REST API route for site meta
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }

    public function add_admin_menu() {
        add_menu_page(
            __('WHM Info Connect', 'whmin-connect'),
            __('WHM Info Connect', 'whmin-connect'),
            'manage_options',
            'whm-info-connect',
            [$this, 'render_admin_page'],
            'dashicons-rest-api',
            80
        );
    }

    public function render_admin_page() {
        // Handle consent form submission
        if (isset($_POST['whmic_consent_action'])) {
            check_admin_referer('whmic_consent_nonce');
            if ($_POST['whmic_consent_action'] === 'accept') {
                update_option('whmic_consent_given', true);
            } else {
                wp_redirect(admin_url());
                exit;
            }
        }

        $consent_given = get_option('whmic_consent_given', false);
        
        echo '<div class="wrap whmic-wrap">';
        if (!$consent_given) {
            require_once WHMIC_PATH . 'templates/consent-page.php';
        } else {
            require_once WHMIC_PATH . 'templates/settings-page.php';
        }
        echo '</div>';
    }

    public function enqueue_assets($hook) {
        if ($hook !== 'toplevel_page_whm-info-connect') {
            return;
        }
        wp_enqueue_style('whmic-admin-css', plugin_dir_url(__FILE__) . 'assets/admin.css', [], WHMIC_VERSION);
        wp_enqueue_script('whmic-admin-js', plugin_dir_url(__FILE__) . 'assets/admin.js', ['jquery'], WHMIC_VERSION, true);
        wp_localize_script('whmic-admin-js', 'WHMIC_Ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('whmic_ajax_nonce')
        ]);
    }
    
    public function ajax_test_connection() {
        check_ajax_referer('whmic_ajax_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.'], 403);
        }
    
        $api_url = esc_url_raw($_POST['api_url'] ?? '');
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
    
        if (empty($api_url) || empty($api_key)) {
            wp_send_json_error(['message' => 'API URL and Key are required.']);
        }
    
        // Test status endpoint on the MAIN site
        $status_url = trailingslashit($api_url) . 'wp-json/whmin/v1/status';
        
        $args = [
            'headers' => ['X-API-Token' => $api_key],
            'timeout' => 15,
            'sslverify' => false, // allow local/staging
        ];
    
        $response = wp_remote_get($status_url, $args);
    
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            update_option('whmic_connection_status', 'failed');
            $error_message = is_wp_error($response) ? $response->get_error_message() : 'Response code was not 200.';
            wp_send_json_error(['message' => 'Connection failed. Please check your URL and API Key. Details: ' . $error_message]);
        }
    
        // If status is OK, call the /activate-connection endpoint on the MAIN site
        $activate_url = trailingslashit($api_url) . 'wp-json/whmin/v1/activate-connection';
        
        $args['body'] = [
            'site_url'   => home_url(),
            'site_name'  => get_bloginfo('name'),
            // OPTIONAL: you could already send some meta here if you want (lightweight)
        ];
    
        $activation_response = wp_remote_post($activate_url, $args);
    
        if (is_wp_error($activation_response) || wp_remote_retrieve_response_code($activation_response) !== 200) {
            update_option('whmic_connection_status', 'failed');
            wp_send_json_error(['message' => 'Activation failed. Ensure this site is added to the In-direct list on the main plugin with the "Standard API Connection" type.']);
        }
    
        // Success!
        update_option('whmic_api_url', $api_url);
        update_option('whmic_api_key', $api_key);
        update_option('whmic_connection_status', 'activated');

        wp_send_json_success(['message' => 'Connection Activated Successfully!']);
    }

    /* =========================================================
     * REST API: site meta endpoint
     * ======================================================= */

    public function register_rest_routes() {
        register_rest_route(
            self::REST_NAMESPACE,
            '/site-meta',
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'rest_get_site_meta'],
                'permission_callback' => [$this, 'rest_permission_check'],
            ]
        );
    }

    /**
     * Permission: require matching X-API-Token header.
     * Uses the same key stored during activation (whmic_api_key).
     */
    public function rest_permission_check($request) {
        $stored_key = get_option('whmic_api_key', '');
        if (empty($stored_key)) {
            return new WP_Error(
                'whmic_no_key',
                __('API key not configured on this site.', 'whmin-connect'),
                ['status' => 403]
            );
        }

        $provided = $request->get_header('x-api-token');
        if (!$provided) {
            // Fallback header name
            $provided = $request->get_header('x-whmin-api-key');
        }

        if (empty($provided) || !hash_equals($stored_key, $provided)) {
            return new WP_Error(
                'whmic_forbidden',
                __('Invalid authentication token.', 'whmin-connect'),
                ['status' => 403]
            );
        }

        return true;
    }

    /**
     * REST callback: return cached site metadata (PHP/WP/theme/plugins/etc).
     */
    public function rest_get_site_meta( \WP_REST_Request $request ) {
        $payload = $this->build_site_meta_payload();
        return rest_ensure_response($payload);
    }

    /**
     * Build the metadata payload, with transient caching to avoid heavy work.
     */
    protected function build_site_meta_payload() {
        // Check cache first
        $cached = get_transient(self::META_TRANSIENT_KEY);
        if (is_array($cached)) {
            return $cached;
        }

        // --- PHP info (whitelisted ini settings only) ---
        $php_info = [
            'version'             => PHP_VERSION,
            'sapi'                => PHP_SAPI,
            'memory_limit'        => ini_get('memory_limit'),
            'max_execution_time'  => (int) ini_get('max_execution_time'),
            'max_input_time'      => (int) ini_get('max_input_time'),
            'max_input_vars'      => (int) ini_get('max_input_vars'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size'       => ini_get('post_max_size'),
            'display_errors'      => (bool) ini_get('display_errors'),
            'log_errors'          => (bool) ini_get('log_errors'),
        ];

        // --- WordPress info ---
        $wp_info = [
            'version'    => get_bloginfo('version'),
            'db_version' => get_option('db_version'),
            'multisite'  => is_multisite(),
            'home_url'   => home_url(),
            'site_url'   => site_url(),
            'language'   => get_bloginfo('language'),
            'debug'      => (defined('WP_DEBUG') && WP_DEBUG),
        ];

        // --- Theme info ---
        $theme = wp_get_theme();
        $parent = $theme->parent();

        $theme_info = [
            'name'         => $theme->get('Name'),
            'version'      => $theme->get('Version'),
            'template'     => $theme->get_template(),
            'stylesheet'   => $theme->get_stylesheet(),
            'is_child'     => $parent ? true : false,
            'parent_name'  => $parent ? $parent->get('Name') : '',
            'parent_theme' => $parent ? $parent->get_template() : '',
        ];

        // --- Plugins info (active only) ---
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $active_plugins = (array) get_option('active_plugins', []);
        if (is_multisite()) {
            $network_plugins = array_keys((array) get_site_option('active_sitewide_plugins', []));
            $active_plugins  = array_unique(array_merge($active_plugins, $network_plugins));
        }

        $all_plugins = function_exists('get_plugins') ? get_plugins() : [];
        $plugins_info = [];

        foreach ($active_plugins as $plugin_file) {
            $data = isset($all_plugins[$plugin_file]) ? $all_plugins[$plugin_file] : [];
            $plugins_info[] = [
                'file'    => $plugin_file,
                'name'    => $data['Name']    ?? '',
                'version' => $data['Version'] ?? '',
                'author'  => $data['Author']  ?? '',
            ];
        }

        // --- Server info (lightweight only) ---
        $server_info = [
            'software'   => isset($_SERVER['SERVER_SOFTWARE']) ? sanitize_text_field($_SERVER['SERVER_SOFTWARE']) : '',
            'php_uname'  => php_uname('s') . ' ' . php_uname('r'),
        ];

        // --- Site info (general) ---
        $site_info = [
            'name'       => get_bloginfo('name'),
            'description'=> get_bloginfo('description'),
            'url'        => home_url(),
        ];

        $payload = [
            'site'        => $site_info,
            'php'         => $php_info,
            'wordpress'   => $wp_info,
            'theme'       => $theme_info,
            'plugins'     => [
                'active'       => $plugins_info,
                'total_active' => count($plugins_info),
            ],
            'server'      => $server_info,
            'generated_at'=> time(),
        ];

        // Cache it to avoid performance impact
        $ttl = apply_filters('whmic_site_meta_cache_ttl', 6 * HOUR_IN_SECONDS);
        if ($ttl > 0) {
            set_transient(self::META_TRANSIENT_KEY, $payload, $ttl);
        }

        return $payload;
    }
}

new WHM_Info_Connect();
